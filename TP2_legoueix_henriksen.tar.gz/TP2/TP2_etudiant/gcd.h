#ifndef GCD_REGS_H
#define GCD_REGS_H

enum SoclibLcdRegisters {
    GCD_OPA = 0,
    GCD_OPB = 1,
    GCD_START  = 2,
    GCD_STATUS = 3,
    /**/
    GCD_SPAN  = 4,
};

#endif 


